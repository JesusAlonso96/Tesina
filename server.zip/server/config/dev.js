
module.exports = {
    DB_URL: "mongodb://localhost/tesina",
    SECRET: "homelessProyecto2019"
}