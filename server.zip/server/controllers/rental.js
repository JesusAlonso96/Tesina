const Rental = require('../models/rental');

exports.getUserRentals = function (req, res) {
    Rental.find({ owner: req.params.id })
        .exec(function (err, foundRentals) {
            if (err) {
                return res.status(422).send({ title: 'Error', details: 'No se pudieron obtener los alquileres' });
            }
            return res.json(foundRentals);
        })
}
exports.postRental = function (req, res) {
    const { lane, number, suburb, pc, closeTo, title, description, cost, likes, dislikes, date, features, photos, owner } = req.body;
    const rental = new Rental({
        lane: lane,
        number: number,
        suburb: suburb,
        pc: pc,
        closeTo: closeTo,
        title: title,
        description: description,
        cost: cost,
        likes: likes,
        dislikes: dislikes,
        date: date,
        features: features,
        photos: photos,
        owner: owner
    });
    rental.save(function (err) {
        if (err) {
            return res.status(422).send({ title: 'Error', details: 'No se pudo realizar la publicacion' });
        }
        return res.json({title:'Alquiler publicado', details:'La publicacion se creo con exito'});
    })
}
